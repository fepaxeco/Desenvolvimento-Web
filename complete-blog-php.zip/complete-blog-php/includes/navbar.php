<div class="navbar">
	<div class="logo_div">
		<a href="index.php"><h1>ProgramerBlog</h1></a>
	</div>
	<ul>
	  <li><a href="#news"></a></li>
	  <li><a href="#contact"></a></li>
	  <li><a href="#about"></a></li>
	</ul>
</div>