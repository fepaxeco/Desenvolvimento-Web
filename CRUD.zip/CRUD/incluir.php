<?php

$mysqli = new mysqli ('localhost', 'root', '', 'agenda') or die (mysqli_error($mysqli));

 $ID = 0;
 $update = false;
 $nome = '';
 $email = '';
 $telefone = '';


if (isset($_POST ['salvar']))
{
	$nome = $_POST['nome'];
	$email = $_POST['email']; 
	$telefone = $_POST['telefone'];

	$mysqli -> query("INSERT INTO dados (nome, email, telefone) VALUES ('$nome', '$email', '$telefone')") or die ($mysqli->error());
		header('location: index.php');

}

if (isset($_GET ['delete']))
{
	$id = $_GET ['delete'];

	$mysqli -> query("DELETE FROM dados WHERE id=$id") or die ($mysqli->error());
		
		header('location: index.php');

}

if (isset($_GET ['edit']))
{
	$id = $_GET ['edit'];
	$update = true;
	$result = $mysqli -> query("SELECT * FROM dados WHERE id=$id") or die ($mysqli->error());

	if(@count($result) ==1)
	{
		$row = $result->fetch_array();
		$nome = $row['nome'];
		$email = $row['email'];
		$telefone = $row['telefone'];
	}
}

if(isset($_POST['update']))
{
	$id = $_POST ['id'];
	$nome = $_POST ['nome'];
	$email = $_POST ['email'];
	$telefone = $_POST ['telefone'];	

	$mysqli -> query("UPDATE dados SET nome='$nome', email='$email', telefone = '$telefone' WHERE id=$id") or die ($mysqli->error);

	header('location: index.php');

}