<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>CRUD</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>
  <body>
    <?php require_once 'incluir.php' ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">CRUD</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Create</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Retrieve</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Update</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Delete</a>
      </li>
    </ul>
  </div>
</nav>


    <div class="container">
    <?php 
              $mysqli = new mysqli ('localhost', 'root', '', 'agenda') or die (mysqli_error($mysqli));
              $result = $mysqli -> query ("SELECT * FROM dados") or die ($mysqli -> error);
              //pre_r($result);

    ?>

        <div class="row justify-content-center">
            <table class="table">
                <thead class="thead-light">
                     <tr>
                          <th>Nome</th>
                          <th>Email</th>
                          <th>Telefone</th>
                          <th colspan="2">Opções</th>
                    </tr>
                </thead> 

           <?php
              while($row = $result -> fetch_assoc()):
            ?>  
               <tr>
                  <td> <?php echo $row ['nome']; ?> </td>
                  <td> <?php echo $row ['email']; ?> </td>
                  <td> <?php echo $row ['telefone']; ?> </td> 
                  <td> 
                      <a href= "index.php?edit= <?php echo $row['id']; ?>" 
                        class = "btn btn-info">Editar</a>    

                      <a href= "incluir.php?delete= <?php echo $row['id']; ?>" 
                        class = "btn btn-danger">Delete</a>  

                  </td>
               </tr>

            <?php endwhile ?>    
            </table>
        </div>



    <div class="row justify-content-center">
      <form class="form" action="incluir.php" method="POST">
        <input type ="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-label-group">
                <input type="nome"  name="nome" value="<?php echo $nome; ?>" class="form-control"  placeholder="Nome" required autofocus>
                <label for="inputNome"></label>
            </div>

            <div class="form-label-group">
                <input type="email"  name="email" 
                value="<?php echo $email; ?>" class="form-control" placeholder="Email" required autofocus>
                 <label for="inputEmail"></label>
            </div>

            <div class="form-label-group">
                <input type="telefone"  name="telefone" 
                value="<?php echo $telefone; ?>" class="form-control"  placeholder="Telefone" required>
                <label for="inputTelefone"></label>
            </div>

            <div class="form-group">
                <?php 
                if($update == true): 
                ?>
                    <button class="btn btn-info btn-block" type="submit" name= "update" >Editar</button>

                    <?php else: ?>

                    <button class="btn btn-primary btn-block" type="submit" name= "salvar" >Salvar</button>

                <?php endif ?>
            </div>

     </form>
 </div>
</div>
  </body>
</html>